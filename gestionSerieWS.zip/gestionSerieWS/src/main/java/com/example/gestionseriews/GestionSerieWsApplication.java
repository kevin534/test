package com.example.gestionseriews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionSerieWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionSerieWsApplication.class, args);
	}

}
